// server.js
const express = require('express');
const fetch = require('node-fetch'); // npm install node-fetch@2
const app = express();
const PORT = process.env.PORT || 3000;

// Your secrets (use environment variables in production)
const GHL_API_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2NhdGlvbl9pZCI6IlhsSEJwSUhLUUVnbVNpS3NXc3l1IiwiY29tcGFueV9pZCI6IjJZdFFOcVRYcVVxNG44U3NyZ29ZIiwidmVyc2lvbiI6MSwiaWF0IjoxNzAyMTIyODY4NzM1LCJzdWIiOiJ1c2VyX2lkIn0.tGCt8AaT3KRVGPXaV_eNK7DF-1jto6vKol254BhKkJ8';
const CUSTOM_OBJECT_ID = '6736098a9891e42180b44839';

app.get('/properties', async (req, res) => {
  try {
    const ghlResponse = await fetch(`https://rest.gohighlevel.com/v1/custom-objects/${CUSTOM_OBJECT_ID}/records`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${GHL_API_KEY}`,
        'Content-Type': 'application/json',
        'Version': '2021-07-28'
      }
    });

    const data = await ghlResponse.json();
    res.setHeader('Access-Control-Allow-Origin', '*'); // Allow CORS
    res.json(data);
  } catch (error) {
    console.error('Error fetching GHL data:', error);
    res.status(500).send('Error fetching properties');
  }
});

app.listen(PORT, () => {
  console.log(`Proxy server running on port ${PORT}`);
});
